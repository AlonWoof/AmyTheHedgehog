using UnityEngine;

public static class GamePreferencesManager
{
    // const string ScoreKey = "Score";

    public static void SavePrefs()
    {
        // PlayerPrefs.SetInt(ScoreKey, GameViewController.Instance.CurrentScore);
        // PlayerPrefs.Save();
    }

    public static void LoadPrefs()
    {
        // var score = PlayerPrefs.GetInt(ScoreKey, 0);
        // GameViewController.Instance.CurrentScore = score;
    }
}